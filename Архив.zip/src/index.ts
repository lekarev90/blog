import {test} from "./test";

test(15)
