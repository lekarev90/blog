export const test = (num: number): number => {
    console.log(num);
    return num
}
